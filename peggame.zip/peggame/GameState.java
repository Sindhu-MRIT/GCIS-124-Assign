package peggame;

public enum GameState
{
    NOT_STARTED,
    IN_PROGRESS,
    STALEMATE,
    WON;  //enum
}