package peggame;

public class PegGameException extends Exception 
{
    public PegGameException(String msg) {
        super(msg);  //displaying error
    }
}
